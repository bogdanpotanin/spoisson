#ifndef spoisson_msel_H
#define spoisson_msel_H

#include <RcppArmadillo.h>

using namespace Rcpp;
using namespace RcppArmadillo;

double rss_spoisson(const arma::vec par,
                    const List control_rss,
                    const String out_type);

#endif
