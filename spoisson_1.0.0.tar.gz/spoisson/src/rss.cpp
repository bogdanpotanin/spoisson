#define ARMA_DONT_USE_OPENMP
#include <RcppArmadillo.h>
using namespace Rcpp;

#ifdef _OPENMP
// [[Rcpp::plugins(openmp)]]
#endif

//' Residuals sum of squares of the Poisson model.
//' @description Calculates residuals sum of squares of the Poisson model.
//' @param par numeric vector of parameters.
//' @param control_rss list of data and some other information.
//' @param out_type string representing the output type of the function.
//' @export
// [[Rcpp::export(rng = false)]]
NumericMatrix rss_spoisson(const arma::vec par,
                           const List control_rss,
                           const String out_type = "val")
{
  // Determine whether gradient and Jacobian should be estimated
  const bool is_grad = (out_type == "grad");
  const bool is_jac  = (out_type == "jac");
  const bool is_diff = is_grad | is_jac;
  arma::mat jac;

  // Get information on the dimensions of the data
  const int n_par2  = control_rss["n_par2"];
  const int n_obs   = control_rss["n_obs"];

  // Get indexes of the observations for different regimes
  const arma::uvec ind0 = control_rss["ind0"];
  const arma::uvec ind1 = control_rss["ind1"];

  // Determine the indexes of the parameters
  const arma::uvec coef0_ind = control_rss["coef0_ind"];
  const arma::uvec coef1_ind = control_rss["coef1_ind"];
  const arma::uvec rho0_ind  = control_rss["rho0_ind"];
  const arma::uvec rho1_ind  = control_rss["rho1_ind"];

  // Get observable regimes
  const bool is0 = control_rss["is0"];
  const bool is1 = control_rss["is1"];

  // Assign the values
  const arma::vec coef0 = par.elem(coef0_ind);
  const arma::vec coef1 = par.elem(coef1_ind);
  const double rho0     = par.elem(rho0_ind).eval().at(0);
  const double rho1     = par.elem(rho1_ind).eval().at(0);

  // Validate the correlation coefficients
  if ((((rho0 >= 1.0) | (rho0 <= -1.0)) & is0) |
      (((rho1 >= 1.0) | (rho1 <= -1)) & is1))
  {
    if (is_diff)
    {
      NumericMatrix out_tmp(n_par2, 1);
      std::fill(out_tmp.begin(), out_tmp.end(), 1e+100);
      return(out_tmp);
    }
    NumericMatrix out_tmp(1,1);
    out_tmp(0, 0) = 1e+100;
    return(out_tmp);
  }

  // Get data
  const arma::vec z  = control_rss["z"];
  const arma::vec y  = control_rss["y"];
  const arma::mat w  = control_rss["w"];
  const arma::mat x0 = control_rss["x0"];
  const arma::mat x1 = control_rss["x1"];
  const arma::vec lp = control_rss["lp"];

  // Conditional mean
  arma::vec mu_share = arma::zeros(n_obs);
  arma::vec mu       = arma::zeros(n_obs);

  // Regime 1 conditional mean
  if (is1)
  {
    mu_share.elem(ind1) = arma::exp(x1.rows(ind1) * coef1 + 0.5) /
                          arma::normcdf(lp.elem(ind1));
    mu.elem(ind1)       = mu_share.elem(ind1) %
                          arma::normcdf(lp.elem(ind1) + rho1);
  }

  // Regime 0 conditional mean
  if (is0)
  {
    mu_share.elem(ind0) = arma::exp(x0.rows(ind0) * coef0 + 0.5) /
                          arma::normcdf(-lp.elem(ind0));
    mu.elem(ind0)       = mu_share.elem(ind0) %
                          arma::normcdf(-(lp.elem(ind0) + rho0));
  }

  // Calculate the residuals and their squares
  arma::vec res = arma::zeros(n_obs);
  if (is0)
  {
    res.elem(ind0) = y.elem(ind0) - mu.elem(ind0);
  }
  if (is1)
  {
    res.elem(ind1) = y.elem(ind1) - mu.elem(ind1);
  }
  arma::vec res2 = arma::pow(res, 2);

  // Calculate the sum of squared residuals
  double rss = arma::sum(res2);

  // Calculate the Jacobian
  if (is_diff)
  {
    // Prepare the Jacobian
    jac = arma::mat(n_obs, n_par2);

    // Jacobian respect to coef1
    if (is1)
    {
      arma::mat x1_submat         = x1.rows(ind1);
      jac.submat(ind1, coef1_ind) += x1_submat.each_col() %
                                     (-2 * res.elem(ind1) % mu.elem(ind1));
    }

    // Jacobian respect to coef0
    if (is0)
    {
      arma::mat x0_submat         = x0.rows(ind0);
      jac.submat(ind0, coef0_ind) += x0_submat.each_col() %
                                     (-2 * res.elem(ind0) % mu.elem(ind0));
    }

    // Jacobian respect to rho1
    if (is1)
    {
      jac.submat(ind1, rho1_ind) += -2 * res.elem(ind1) % mu_share.elem(ind1) %
                                    arma::normpdf(rho1 + lp.elem(ind1));
    }

    // Jacobian respect to rho0
    if (is0)
    {
      jac.submat(ind0, rho0_ind) += 2 * res.elem(ind0) % mu_share.elem(ind0) %
                                    arma::normpdf(rho0 + lp.elem(ind0));
    }

    // Return the Jacobian
    if (is_jac)
    {
      return(wrap(jac));
    }

    // Calculate the gradient
    if (is_grad)
    {
      arma::mat grad = arma::ones(1, n_obs) * jac;
      return(wrap(grad));
    }
  }

  // Return the results
  NumericMatrix out_rss(1, 1);
  out_rss(0, 0) = rss;
  return(out_rss);
}

//' Gradient of the residuals sum of squares of the Poisson model.
//' @description Calculates residuals sum of squares of the Poisson model.
//' @param par numeric vector of parameters.
//' @param control_rss list of data and some other information.
//' @param out_type string representing the output type of the function.
//' @export
// [[Rcpp::export(rng = false)]]
NumericMatrix drss_spoisson(const arma::vec par,
                            const List control_rss,
                            const String out_type = "val")
{
  return(rss_spoisson(par, control_rss, "grad"));
}
