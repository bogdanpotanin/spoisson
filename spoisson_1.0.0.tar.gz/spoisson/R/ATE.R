#' Estimate ATE and ATET for a spoisson Object.
#' @description This function estimates average treatment effect (ATE) and
#' average treatment effect on the treated (ATET).
#' @param object an object of class \code{spoisson}.
#' @return Returns a numeric vector which elements are estimates of the average
#' treatment effect (ATE) and average treatment effect on the treated (ATET)
#' for a Poisson endogenous switching model.
ATE_spoisson <- function(object)
{
  # Get the predictions
  val <- predict(object)

  # Estimate the ATE
  ATE <- mean(na.omit(val[, "mu1"] - val[, "mu0"]))

  # Estimate the ATET
  ATET <- mean(na.omit((val[, "mu1c1"] - val[, "mu0c1"])[object$z == 1]))

  # Return the results
  c("ATE" = ATE, "ATET" = ATET)
}

