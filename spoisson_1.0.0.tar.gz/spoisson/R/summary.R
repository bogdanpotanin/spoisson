#' Summary for an Object of Class spoisson
#' @description Provides summary for an object of class 'spoisson'.
#' @param object object of class 'spoisson'
#' @param ... further arguments (currently ignored)
#' @return Returns an object of class 'summary.spoisson'.
summary.spoisson <- function(object, ...)
{
  if (length(list(...)) > 0)
  {
    warning("Additional arguments passed through ... are ignored.")
  }

  class(object) <- "summary.spoisson"

  return(object)
}

#' Print summary for an Object of Class spoisson
#' @description Prints summary for an object of class 'spoisson'.
#' @param x object of class 'spoisson'
#' @param ... further arguments (currently ignored)
#' @return The function returns \code{x}.
print.summary.spoisson <- function(x, ...)
{
  # Assign the class
  class(x) <- "spoisson"

  # Create table for the first step estimates
  tbls <- cbind(Estimate  = x$coefs_est,
                Std_Error = x$se[x$coefs_ind],
                z_value   = x$z_value[x$coefs_ind],
                p_value   = x$p_value[x$coefs_ind])

  # Create table for the coefficients estimates in regime 0
  tbl1 <- cbind(Estimate  = x$coef1_est,
                Std_Error = x$se[x$coef1_ind],
                z_value   = x$z_value[x$coef1_ind],
                p_value   = x$p_value[x$coef1_ind])

  # Create table for the coefficients estimates in regime 1
  tbl0 <- cbind(Estimate  = x$coef0_est,
                Std_Error = x$se[x$coef0_ind],
                z_value   = x$z_value[x$coef0_ind],
                p_value   = x$p_value[x$coef0_ind])

  # Create table for the estimates of rho in regime 0
  tblr0 <- cbind(Estimate  = x$rho0_est,
                 Std_Error = x$se[x$rho0_ind],
                 z_value   = x$z_value[x$rho0_ind],
                 p_value   = x$p_value[x$rho0_ind])

  # Create table for the estimates of rho in regime 1
  tblr1 <- cbind(Estimate  = x$rho1_est,
                 Std_Error = x$se[x$rho1_ind],
                 z_value   = x$z_value[x$rho1_ind],
                 p_value   = x$p_value[x$rho1_ind])

  # The header
  cat("Endogenous switching Poisson model\n")
  cat("--- \n")

  # First step
  cat(paste0(x$z_name, " equation \n"))
  printCoefmat(tbls,
               has.Pvalue = TRUE, signif.legend = FALSE, P.values = TRUE)

  # Second step
  cat("--- \n")
  cat(paste0(x$y_name, " equation \n"))

  # Regime 0
  if (x$is0)
  {
    cat("-- \n")
    cat("Regime 0 \n")
    cat("- \n")
    cat("Coefficients \n")
    printCoefmat(tbl0,
                 has.Pvalue = TRUE, signif.legend = FALSE, P.values = TRUE)
    cat("- \n")
    cat("Correlation \n")
    printCoefmat(tblr0,
                 has.Pvalue = TRUE, signif.legend = FALSE, P.values = TRUE)
  }

  # Regime 1
  if (x$is1)
  {
    cat("-- \n")
    cat("Regime 1 \n")
    cat("- \n")
    cat("Coefficients \n")
    printCoefmat(tbl1,
                 has.Pvalue = TRUE, signif.legend = FALSE, P.values = TRUE)
    cat("- \n")
    cat("Correlation \n")
    printCoefmat(tblr1,
                 has.Pvalue = TRUE, signif.legend = FALSE, P.values = TRUE)
  }

  # Show the stars legend
  if (getOption("show.signif.stars"))
  {
    cat("--- \n")
    cat("Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1 \n")
  }

  # Return the results
  return(x)
}
