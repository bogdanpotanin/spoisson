#' Extracts Variance-Covariance Matrix for a spoisson Object.
#' @description Return the variance-covariance matrix of the parameters of
#' spoisson model.
#' @param object an object of class \code{spoisson}.
#' @param ... further arguments (currently ignored).
#' @return Returns numeric matrix which represents estimate of the asymptotic
#' covariance matrix of model's parameters.
vcov.spoisson <- function(object, ...)
{
  # Validate dots
  if (length(list(...)) > 0)
  {
    warning("Additional arguments passed through ... are ignored.")
  }

  # Return the results
  return(object$vcov)
}

#' Extract the Number of Observations from a Fit of the spoisson Function.
#' @description Extract the number of observations from a model fit
#' of the \code{\link[spoisson]{spoisson}} function.
#' @param object object of class "spoisson"
#' @param ... further arguments (currently ignored)
#' @return A single positive integer number.
nobs.spoisson <- function(object, ...)
{
  if (length(list(...)) > 0)
  {
    warning("Additional arguments passed through ... are ignored.")
  }

  return(object$n_obs)
}
