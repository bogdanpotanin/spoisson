#' Endogenous switching Poisson model
#' @description This function implements two-step estimator of the endogenous
#' switching Poisson model. It may also be used for sample selection Poisson
#' model.
#' @param selection an object of class \code{"formula"} describing the
#' endogenous switching probit equation. Right hand side should be a numeric
#' variable taking values 0 and 1.
#' @param outcome1 an object of class \code{"formula"} describing the Poisson
#' outcome equation in regime 1.
#' @param outcome0 an object of class \code{"formula"} describing the Poisson
#' outcome equation in regime 0.
#' @param common an object of class \code{"formula"}. Its right hand side
#' contains the regressors which coefficients should be restricted to be
#' the same for regimes 0 and 1. Special values \code{Intercept} and
#' \code{rho} state for the intercept and correlation coefficient, respectively.
#' Special character value \code{common = "er"} makes all the coefficients the
#' same except for the intercept. Therefore this option produces endogenous
#' regressor model.
#' @param data a data frame containing the variables in the model.
#' @template spoisson_details_Template
#' @template spoisson_references_Template
#' @template spoisson_examples_Template
spoisson <- function(selection = NA,
                     outcome1  = NA,
                     outcome0  = NA,
                     common    = NA,
                     data      = NULL)
{
  # List to store the output
  out        <- list()
  class(out) <- "spoisson"

  # Validate formulas
  if (is.character(common))
  {
    if (common == "er")
    {
      outcome0 <- outcome1
      common   <- paste0(as.character(outcome0)[[3]], " + rho")
      common   <- paste0(as.character(model$outcome0[[2]]), " ~ ", common)
      common   <- as.formula(common)
    }
  }
  if (!is(object = selection, class2 = "formula"))
  {
    stop("Argument 'selection' should be a formula.")
  }
  is0 <- is(object = outcome0, class2 = "formula")
  is1 <- is(object = outcome1, class2 = "formula")
  if (!is0)
  {
    if (!is.na(outcome0))
    {
      outcome0 <- as.formula(outcome0)
      is0      <- TRUE
    }
  }
  if (!is1)
  {
    if (!is.na(outcome1))
    {
      outcome1 <- as.formula(outcome1)
      is1      <- TRUE
    }
  }
  out$is0 <- is0
  out$is1 <- is1
  if (!is0 & !is1)
  {
    stop("At least one outcome should be provided.")
  }

  # Save formulas
  out$selection <- selection
  out$outcome0  <- outcome0
  out$outcome1  <- outcome1

  # Get data according to the formulas
  dfs <- model.frame(selection, data, na.action = na.pass)
  df0 <- matrix(rep(1, nrow(data)), ncol = 1)
  df1 <- matrix(rep(1, nrow(data)), ncol = 1)
  if (is0)
  {
    df0 <- model.frame(outcome0, data, na.action = na.pass)
  }
  if (is1)
  {
    df1 <- model.frame(outcome1, data, na.action = na.pass)
  }

  # Remove missing values
  data <- data[complete.cases(dfs) &
               (complete.cases(df0) | (dfs[, 1, drop = FALSE] == 1)) &
               (complete.cases(df1) | (dfs[, 1, drop = FALSE] == 0)), ]

  # Recreate data frame without missing values
  dfs <- model.frame(selection, data, na.action = na.pass)
  if (is0)
  {
    df0 <- model.frame(outcome0,  data, na.action = na.pass)
  }
  if (is1)
  {
    df1 <- model.frame(outcome1,  data, na.action = na.pass)
  }

  # Get the dependent variables
  z <- dfs[, 1]
  y <- NA
  if (is0)
  {
    y <- df0[, 1]
  }
  else
  {
    y <- df1[, 1]
  }

  # Get the regressors
  w  <- as.matrix(cbind(1, dfs[, -1, drop = FALSE]))
  x0 <- as.matrix(cbind(1, df0[, -1, drop = FALSE]))
  x1 <- as.matrix(cbind(1, df1[, -1, drop = FALSE]))

  # Get the names
  z_name   <- c(colnames(dfs)[1])
  y_name   <- c(colnames(df0)[1])
  w_names  <- c("(Intercept)", colnames(dfs)[-1])
  x0_names <- c("(Intercept)", colnames(df0)[-1])
  x1_names <- c("(Intercept)", colnames(df1)[-1])

  # Assign the names
  colnames(w)  <- w_names
  colnames(x0) <- x0_names
  colnames(x1) <- x1_names

  # Get the number of observations
  n_obs <- length(y)

  # Get the number of coefficients
  n_coefs <- length(w_names)
  n_coef0 <- 0
  n_coef1 <- 0
  n_rho   <- is0 + is1
  if (is0)
  {
    n_coef0 <- length(x0_names)
  }
  if (is1)
  {
    n_coef1 <- length(x1_names)
  }

  # Deal with the common parameters
  isc         <- is(object = common, class2 = "formula")
  c_names     <- NULL
  xc_names    <- NULL
  is_c_rho    <- FALSE
  coef1_c_ind <- NULL
  n_c         <- 0
  n_xc        <- 0
  if (isc)
  {
    # All common variables
    c_names                                <- labels(terms(common))
    c_names[which(c_names == "Intercept")] <- "(Intercept)"

    # Common regressors
    xc_names <- c_names[which(c_names != "rho")]

    # Does correlation is common
    is_c_rho <- any(c_names == "rho")

    # Total number of common parameters
    n_xc <- length(xc_names)
    n_c  <- is_c_rho + n_xc
  }

  # Calculate a total number of the parameters
  n_par  <- n_coefs + n_coef0 + n_coef1 + n_rho - n_c
  n_par2 <- n_par - n_coefs

  # Assign the indexes of the parameters
  counter   <- 1
  coefs_ind <- 1
  coef0_ind <- 1
  coef1_ind <- 1
  rho0_ind  <- 1
  rho1_ind  <- 1
  if (is0)
  {
    coef0_ind <- counter:n_coef0
    counter   <- coef0_ind[length(coef0_ind)] + 1
  }
  if (is1)
  {
    if (isc & (n_xc > 0))
    {
      coef1_ind            <- rep(NA, n_coef1)
      xc_in_x1             <- na.omit(match(xc_names, x1_names))
      xc_in_x0             <- na.omit(match(xc_names, x0_names))
      coef1_ind[xc_in_x1]  <- coef0_ind[xc_in_x0]
      if (n_xc != n_coef1)
      {
        coef1_ind[-xc_in_x1] <- counter:(counter + n_coef1 - n_xc - 1)
      }
    }
    else
    {
      coef1_ind <- counter:(counter - 1 + n_coef1)
    }
    counter <- max(coef1_ind) + 1
  }
  if (is0)
  {
    rho0_ind <- counter
    counter  <- rho0_ind + 1
  }
  if (is1)
  {
    rho1_ind <- counter - is_c_rho
    counter  <- rho1_ind + 1
  }
  coefs_ind <- counter:n_par

  # Indexes of the observations
  ind0 <- which(z == 0)
  ind1 <- which(z == 1)

  # Vector to store estimates of the parameters
  par_est <- rep(NA, n_par)

  # Vector to store starting values for the optimization routine
  start <- rep(1e-3, n_par2)

  # The first step
  model1 <- msel(selection, data = data, cov_type = "sandwich")
  lp     <- as.vector(predict(model1, type = "lp", group = 1) -
                      coef(model1, type = "cuts", eq = 1))

  # Get starting values for the optimization
  modelp0 <- NA
  modelp1 <- NA
  if (is0)
  {
    modelp0          <- glm(outcome0, data = data[z == 0, ], family = "poisson")
    start[coef0_ind] <- modelp0$coefficients
  }
  if (is1)
  {
    modelp1          <- glm(outcome1, data = data[z == 1, ], family = "poisson")
    start[coef1_ind] <- modelp1$coefficients
  }

  # Collect preliminary information into the output
  out$z         <- z
  out$y         <- y
  out$w         <- w
  out$x0        <- x0
  out$x1        <- x1
  out$n_obs     <- n_obs
  out$n_par     <- n_par
  out$n_par2    <- n_par2
  out$coefs_ind <- coefs_ind
  out$coef0_ind <- coef0_ind
  out$coef1_ind <- coef1_ind
  out$rho0_ind  <- rho0_ind
  out$rho1_ind  <- rho1_ind
  out$lp        <- lp
  out$n_coefs   <- n_coefs
  out$n_coef0   <- n_coef0
  out$n_coef1   <- n_coef1
  out$ind1      <- ind1
  out$ind0      <- ind0
  out$start     <- start

  # Collect information to the control
  control_rss           <- out
  control_rss$coefs_ind <- control_rss$coefs_ind - 1
  control_rss$coef0_ind <- control_rss$coef0_ind - 1
  control_rss$coef1_ind <- control_rss$coef1_ind - 1
  control_rss$rho0_ind  <- control_rss$rho0_ind - 1
  control_rss$rho1_ind  <- control_rss$rho1_ind - 1
  if (is1)
  {
    control_rss$ind1 <- control_rss$ind1 - 1
  }
  if (is0)
  {
    control_rss$ind0 <- control_rss$ind0 - 1
  }

  # The second step
  opt <- optim(par     = start,
               fn      = rss_spoisson,
               gr      = drss_spoisson,
               method  = "BFGS",
               hessian = TRUE,
               control = list(maxit   = 1000000,
                              reltol  = 1e-10),
               control_rss = control_rss)

  # Store the estimates
  par_est[coefs_ind] <- c(-coef(model1, type = "cuts", eq = 1),
                           coef(model1, type = "coef", eq = 1))
  if (is0)
  {
    par_est[coef0_ind] <- opt$par[coef0_ind]
    par_est[rho0_ind]  <- opt$par[rho0_ind]
  }
  if (is1)
  {
    par_est[coef1_ind] <- opt$par[coef1_ind]
    par_est[rho1_ind]  <- opt$par[rho1_ind]
  }

  # Assign the estimates
  coef0_est <- NA
  coef1_est <- NA
  rho0_est  <- NA
  rho1_est  <- NA
  coefs_est <- par_est[coefs_ind]
  if (is0)
  {
    coef0_est <- par_est[coef0_ind]
    rho0_est  <- par_est[rho0_ind]
  }
  if (is1)
  {
    coef1_est <- par_est[coef1_ind]
    rho1_est  <- par_est[rho1_ind]
  }

  # Provide names to the estimates
  names(coefs_est) <- w_names
  if (is0)
  {
    names(coef0_est) <- x0_names
    names(rho0_est)  <- "rho0"
  }
  if (is1)
  {
    names(coef1_est) <- x1_names
    names(rho1_est)  <- "rho1"
  }

  # Store estimates to the output
  out$par_est   <- par_est
  out$coefs_est <- coefs_est
  out$coef0_est <- coef0_est
  out$coef1_est <- coef1_est
  out$rho0_est  <- rho0_est
  out$rho1_est  <- rho1_est

  # Prepare the matrices to store Jacobian and Hessian
  J <- matrix(0, nrow = n_obs, ncol = n_par)
  H <- matrix(0, nrow = n_par, ncol = n_par)

  # Store the information from the first step
  J[, (n_par2+1):n_par]                 <- model1$J
  J[, n_par2 + 1]                       <- -J[, n_par2 + 1]
  H[(n_par2+1):n_par, (n_par2+1):n_par] <- model1$H

  # Store the information from the second step
  J[, 1:n_par2]         <- rss_spoisson(par         = opt$par,
                                        control_rss = control_rss,
                                        out_type    = "jac")
  H[1:n_par2, 1:n_par2] <- opt$hessian

  # Estimate asymptotic covariance matrix via sandwich estimator
  H_inv    <- qr.solve(H)
  vcov     <- H_inv %*% t(J) %*% J %*% H_inv
  out$vcov <- vcov
  out$H    <- H
  out$J    <- J

  # Estimate standard errors
  se     <- sqrt(diag(vcov))
  out$se <- se

  # Calculate p-values
  z_value  <- par_est / se
  p_value <- rep(NA, n_par)
  for (i in 1:n_par)
  {
    p_value[i] <- 2 * min(pnorm(z_value[i]), 1 - pnorm(z_value[i]))
  }
  out$z_value <- z_value
  out$p_value <- p_value

  # Save some more information
  out$start   <- start
  out$modelp0 <- modelp0
  out$modelp1 <- modelp1
  out$model1  <- model1
  out$z_name  <- z_name
  out$y_name  <- y_name
  out$data    <- data
  out$common  <- common

  # Return the results
  return(out)
}
