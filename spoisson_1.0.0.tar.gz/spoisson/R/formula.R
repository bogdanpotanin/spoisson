#' Formulas of spoisson model.
#' @description Provides formulas associated with the
#' object of class 'spoisson'.
#' @param x object of class 'spoisson'.
#' @param ... further arguments (currently ignored).
#' @param type character;
#' if \code{type = "all"} then function returns a list of all formulas.
#' if \code{type = "selection"} then function returns
#' \code{selection} input argument.
#' if \code{type = "outcome0"} then function returns
#' \code{outcome0} input argument.
#' if \code{type = "outcome1"} then function returns
#' \code{outcome1} input argument.
#' if \code{type = "common"} then function returns
#' \code{common} input argument.
#' @return Returns a formula or a list of formulas depending on \code{eq} value.
formula.spoisson <- function(x, ..., type = "all")
{
  if (length(list(...)) > 0)
  {
    warning("Additional arguments passed through ... are ignored.")
  }

  # List of all formulas
  frm_list <- list(selection = x$selection,
                   outcome0  = x$outcome0,
                   outcome1  = x$outcome1,
                   common    = x$common)
  if (type == "all")
  {
    return(frm_list)
  }

  # Formula of the selection equation
  if (type == "selection")
  {
    return(x$selection)
  }

  # Formula of the outcome equation in regime 0
  if (type == "outcome0")
  {
    return(x$outcome0)
  }

  # Formula of the outcome equation in regime 1
  if (type == "outcome1")
  {
    return(x$outcome1)
  }

  # Formula of the common variables
  if (type == "common")
  {
    return(x$common)
  }


  stop("Incorrect input argument.")
}
