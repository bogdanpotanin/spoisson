#' Predict method for spoisson function
#' @description Predicted values based on the object of class 'spoisson'.
#' @param object object of class 'spoisson'
#' @param ... further arguments (currently ignored)
#' @param newdata an optional data frame in which to look for variables with which
#' to predict. If omitted, the original data frame used.
#' @return returns a numeric matrix which has the following columns:
#' \itemize{
#' \item \code{prob_sel} - probability of selection \eqn{P(z_{i}=1|w_{i})}.
#' \item \code{mu0} - unconditional (on the selection outcome) expectation
#' \eqn{\text{E}(y_{0i}|x_{i})}.
#' \item \code{mu1} - unconditional (on the selection outcome) expectation
#' \eqn{\text{E}(y_{1i}|x_{i})}.
#' \item \code{mu0c0} - conditional (on the selection outcome) expectation
#' \eqn{\text{E}(y_{0i}|x_{i},w_{i},z_{i}=0)}.
#' \item \code{mu1c1} - conditional (on the selection outcome) expectation
#' \eqn{\text{E}(y_{1i}|x_{i},w_{i},z_{i}=1)}.
#' \item \code{mu0c1} - conditional (on the selection outcome) expectation
#' \eqn{\text{E}(y_{0i}|x_{i},w_{i},z_{i}=1)}.
#' \item \code{mu1c0} - conditional (on the selection outcome) expectation
#' \eqn{\text{E}(y_{1i}|x_{i},w_{i},z_{i}=0)}.
#' }
predict.spoisson <- function(object, ...,   newdata = NULL)
{
  if (length(list(...)) > 0)
  {
    warning("Additional arguments passed through ... are ignored.")
  }

  if (is.null(newdata))
  {
    newdata <- object$data
  }

  # Get data according to the formulas
  dfs <- model.frame(object$selection, newdata, na.action = na.pass)
  df0 <- matrix(rep(1, nrow(newdata)), ncol = 1)
  df1 <- matrix(rep(1, nrow(newdata)), ncol = 1)
  if (object$is0)
  {
    df0 <- model.frame(object$outcome0, newdata, na.action = na.pass)
  }
  if (object$is1)
  {
    df1 <- model.frame(object$outcome1, newdata, na.action = na.pass)
  }

  # Get the dependent variables
  z <- dfs[, 1]
  y <- NA
  if (object$is0)
  {
    y <- df0[, 1]
  }
  else
  {
    y <- df1[, 1]
  }

  # Get the regressors
  w  <- as.matrix(cbind(1, dfs[, -1, drop = FALSE]))
  x0 <- as.matrix(cbind(1, df0[, -1, drop = FALSE]))
  x1 <- as.matrix(cbind(1, df1[, -1, drop = FALSE]))

  # Calculate the linear predictor
  lp <- w %*% object$coefs_est


  # Estimate selection probability
  prob_sel <- pnorm(lp)

  # Estimate unconditional expectations
  mu0 <- exp(x0 %*% object$coef0_est + 0.5)
  mu1 <- exp(x1 %*% object$coef1_est + 0.5)

  # Estimate conditional expectations
  lambda0 <- (1 - pnorm(object$rho0_est + lp)) / (1 - prob_sel)
  lambda1 <-      pnorm(object$rho1_est + lp)  /      prob_sel
  mu0c0 <- mu0 * lambda0
  mu1c1 <- mu1 * lambda1
  mu0c1 <- mu0 * lambda1
  mu1c0 <- mu1 * lambda0

  # Aggregate the results
  out           <- cbind(prob_sel, mu0, mu1, mu0c0,  mu1c1, mu0c1 , mu1c0)
  colnames(out) <- c("prob_sel", "mu0", "mu1",
                     "mu0c0", "mu1c1", "mu0c1", "mu1c0")

  # Return the results
  return(out)
}
