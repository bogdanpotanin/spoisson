#' Coefficients extraction method for spoisson.
#' @description Extract coefficients and other estimates from spoisson object.
#' @param object an object of class "spoisson".
#' @param ... further arguments (currently ignored).
#' @param type a character represeting the type of the output.
#' If \code{type = "all"} returns a list of all the estimated coefficients.
#' If \code{type = "outcome0"} returns the coefficients associated with the
#' 0-th regime.
#' If \code{type = "outcome1"} returns the coefficients associated with the
#' 1-th regime.
#' If \code{type = "selection"} returns the coefficients associated with the
#' selection equation.
#' If \code{type = "rho"} returns the correlation coefficients.
#' @returns Returns coefficients of the model.
coef.spoisson <- function (object, ..., type = "all")
{
  # Validate dots
  if (length(list(...)) > 0)
  {
    warning("Additional arguments passed through ... are ignored.")
  }

  # All the coefficients
  coef_list <- list(coef0 = object$coef0_est,
                    coef1 = object$coef1_est,
                    coefs = object$coefs_est,
                    rho   = c(object$rho0_est, object$rho1_est))
  if (type == "all")
  {
    return(coef_list)
  }

  # coef0
  if (type %in% c("coef0", "outcome0"))
  {
    return(coef_list$coef0)
  }

  # coef1
  if (type %in% c("coef1", "outcome1"))
  {
    return(coef_list$coef1)
  }
F
  # rho
  if (type %in% c("rho", "cor"))
  {
    return(coef_list$rho)
  }

  stop("Incorrect 'type' argument")
}
